# Storytelling de Dados com Python

Um site explicativo que demonstra como criar narrativas envolventes com dados usando Python e pandas.

## 📖 Sobre o Projeto

Este site foi criado para explicar o conceito de **storytelling de dados** através de um exemplo prático em Python. O projeto mostra como transformar dados organizacionais simples em uma narrativa compreensível e envolvente.

## 🚀 Funcionalidades

- **Explicação Conceitual**: Introdução clara ao storytelling de dados
- **Código Interativo**: Visualização do código Python com syntax highlighting
- **Saída Simulada**: Botão para mostrar/ocultar a execução do código
- **Análise Detalhada**: Explicação de cada parte do código
- **Comparação Visual**: Tabelas mostrando "antes e depois" das mudanças
- **Design Responsivo**: Adaptável para desktop, tablet e mobile

## 🛠️ Tecnologias Utilizadas

- **React 18**: Framework JavaScript para interface
- **Vite**: Build tool e servidor de desenvolvimento
- **Tailwind CSS**: Framework CSS para estilização
- **shadcn/ui**: Componentes de interface
- **Lucide React**: Ícones
- **Framer Motion**: Animações (preparado para uso)

## 📋 Pré-requisitos

- Node.js (versão 18 ou superior)
- npm ou pnpm

## 🔧 Instalação e Execução

1. **Clone o repositório**:
   ```bash
   git clone <url-do-repositorio>
   cd storytelling-site
   ```

2. **Instale as dependências**:
   ```bash
   npm install
   # ou
   pnpm install
   ```

3. **Execute o servidor de desenvolvimento**:
   ```bash
   npm run dev
   # ou
   pnpm run dev
   ```

4. **Acesse o site**:
   Abra [http://localhost:5173](http://localhost:5173) no seu navegador

## 🏗️ Build para Produção

Para criar uma versão otimizada para produção:

```bash
npm run build
# ou
pnpm run build
```

Os arquivos serão gerados na pasta `dist/`.

## 📚 Estrutura do Projeto

```
storytelling-site/
├── public/              # Arquivos públicos
├── src/
│   ├── components/      # Componentes React
│   │   └── ui/         # Componentes UI do shadcn
│   ├── assets/         # Imagens e outros assets
│   ├── App.jsx         # Componente principal
│   ├── App.css         # Estilos principais
│   └── main.jsx        # Ponto de entrada
├── index.html          # Template HTML
├── package.json        # Dependências e scripts
└── README.md          # Este arquivo
```

## 🎯 Conceitos Demonstrados

O site explica e demonstra:

1. **Estrutura de Dados**: Como organizar dados em Python
2. **Funções Narrativas**: Criação de funções que contam histórias
3. **Fluxo Narrativo**: Estrutura clássica de narrativa aplicada a dados
4. **Visualização Final**: Apresentação profissional com pandas DataFrame

## 📊 Exemplo de Código

O projeto demonstra um sistema simples de alocação de funcionários:

- **Dados Iniciais**: Funcionários alocados em projetos
- **Evento**: Reunião que resulta em realocações
- **Resultado**: Novo estado apresentado de forma clara

## 🤝 Contribuições

Contribuições são bem-vindas! Sinta-se à vontade para:

- Reportar bugs
- Sugerir melhorias
- Enviar pull requests

## 📄 Licença

Este projeto é de código aberto e está disponível sob a licença MIT.

## 🔗 Links Úteis

- [React Documentation](https://react.dev/)
- [Tailwind CSS](https://tailwindcss.com/)
- [shadcn/ui](https://ui.shadcn.com/)
- [Pandas Documentation](https://pandas.pydata.org/)

---

**Desenvolvido com ❤️ para demonstrar o poder do storytelling de dados**

