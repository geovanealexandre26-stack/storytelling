import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Code, Database, BookOpen, Play, Users, BarChart3, ArrowRight } from 'lucide-react'
import './App.css'

function App() {
  const [showOutput, setShowOutput] = useState(false)

  const pythonCode = `import pandas as pd

departamentos = ["TI", "Marketing", "Vendas"]

alocacoes_funcionarios = {
    "Ronaldo": {"departamento": "TI", "projeto": "Automação"},
    "Maria": {"departamento": "Marketing", "projeto": "Campanha de Verão"},
    "Júlia": {"departamento": "Vendas", "projeto": "Estratégia de Preço"},
    "Ronaldinho": {"departamento": "TI", "projeto": "Análise de Dados"}
}

def alocacao_projeto(funcionario, novo_projeto):
    if funcionario in alocacoes_funcionarios:
        alocacoes_funcionarios[funcionario]["projeto"] = novo_projeto
        print(f"{funcionario} agora está alocado no projeto '{novo_projeto}'.")
    else:
        print(f"Funcionário {funcionario} não encontrado!")

def informacoes_funcionario():
    for funcionario, projeto in alocacoes_funcionarios.items():
        departamento = projeto["departamento"]
        projeto = projeto["projeto"]
        print(f"{funcionario} trabalha no departamento {departamento} e está no projeto '{projeto}'.")

print('Bem-vindo(a) à nossa empresa de dados!\\n')
print(f'Temos três grandes departamentos: {departamentos}\\n')
print('Esses são os funcionários e seus respectivos projetos:')
informacoes_funcionario()
print()

print('Após uma reunião na empresa, foi decidido realocar alguns projetos!\\n')
alocacao_projeto("Ronaldo", "Big Data")
alocacao_projeto("Ronaldinho", "Machine Learning")
print()

print("Matriz com [Funcionário, Departamento, Projeto]:")
matriz = [[funcionario, i["departamento"], i["projeto"]] for funcionario, i in alocacoes_funcionarios.items()]
for linha in matriz:
    print(linha)
print()

print("Relatório final em formato DataFrame:")
df = pd.DataFrame(matriz, columns=["Funcionário", "Departamento", "Projeto"])
print(df)`

  const initialData = [
    { funcionario: "Ronaldo", departamento: "TI", projeto: "Automação" },
    { funcionario: "Maria", departamento: "Marketing", projeto: "Campanha de Verão" },
    { funcionario: "Júlia", departamento: "Vendas", projeto: "Estratégia de Preço" },
    { funcionario: "Ronaldinho", departamento: "TI", projeto: "Análise de Dados" }
  ]

  const finalData = [
    { funcionario: "Ronaldo", departamento: "TI", projeto: "Big Data" },
    { funcionario: "Maria", departamento: "Marketing", projeto: "Campanha de Verão" },
    { funcionario: "Júlia", departamento: "Vendas", projeto: "Estratégia de Preço" },
    { funcionario: "Ronaldinho", departamento: "TI", projeto: "Machine Learning" }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-slate-900 mb-2">
              Storytelling de Dados com Python
            </h1>
            <p className="text-xl text-slate-600">
              Transformando dados em narrativas envolventes e compreensíveis
            </p>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 space-y-12">
        {/* Hero Section */}
        <section className="text-center py-12">
          <div className="max-w-3xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="bg-blue-100 p-4 rounded-full">
                <BookOpen className="w-12 h-12 text-blue-600" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">
              O que é Storytelling de Dados?
            </h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              Storytelling de dados é a arte de comunicar insights de dados de forma envolvente e compreensível. 
              Em vez de apenas apresentar números e gráficos, criamos uma narrativa que ajuda o público a 
              entender o contexto, a importância e as implicações dos dados, tornando a informação mais 
              memorável e acionável.
            </p>
          </div>
        </section>

        {/* Code Section */}
        <section>
          <Card className="shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Code className="w-6 h-6 text-blue-600" />
                <div>
                  <CardTitle className="text-2xl">Código Python - Exemplo Prático</CardTitle>
                  <CardDescription>
                    Um exemplo de como criar uma narrativa com dados organizacionais
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-900 rounded-lg p-6 overflow-x-auto">
                <pre className="text-sm text-slate-100 font-mono leading-relaxed">
                  <code>{pythonCode}</code>
                </pre>
              </div>
              <div className="mt-4 flex justify-center">
                <Button 
                  onClick={() => setShowOutput(!showOutput)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Play className="w-4 h-4 mr-2" />
                  {showOutput ? 'Ocultar Saída' : 'Mostrar Saída do Código'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Output Section */}
        {showOutput && (
          <section className="animate-in slide-in-from-top duration-500">
            <Card className="shadow-lg border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="text-2xl text-green-800">Saída do Código</CardTitle>
                <CardDescription className="text-green-700">
                  Resultado da execução do código Python
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-900 rounded-lg p-6">
                  <pre className="text-sm text-green-400 font-mono leading-relaxed">
{`Bem-vindo(a) à nossa empresa de dados!

Temos três grandes departamentos: ['TI', 'Marketing', 'Vendas']

Esses são os funcionários e seus respectivos projetos:
Ronaldo trabalha no departamento TI e está no projeto 'Automação'.
Maria trabalha no departamento Marketing e está no projeto 'Campanha de Verão'.
Júlia trabalha no departamento Vendas e está no projeto 'Estratégia de Preço'.
Ronaldinho trabalha no departamento TI e está no projeto 'Análise de Dados'.

Após uma reunião na empresa, foi decidido realocar alguns projetos!

Ronaldo agora está alocado no projeto 'Big Data'.
Ronaldinho agora está alocado no projeto 'Machine Learning'.

Matriz com [Funcionário, Departamento, Projeto]:
['Ronaldo', 'TI', 'Big Data']
['Maria', 'Marketing', 'Campanha de Verão']
['Júlia', 'Vendas', 'Estratégia de Preço']
['Ronaldinho', 'TI', 'Machine Learning']

Relatório final em formato DataFrame:
  Funcionário Departamento              Projeto
0     Ronaldo           TI             Big Data
1       Maria    Marketing    Campanha de Verão
2       Júlia       Vendas  Estratégia de Preço
3  Ronaldinho           TI     Machine Learning`}
                  </pre>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* Analysis Section */}
        <section>
          <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">
            Análise Detalhada do Código
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Database className="w-6 h-6 text-purple-600" />
                  <CardTitle>Estrutura de Dados</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-4">
                  O código utiliza um dicionário Python para armazenar informações dos funcionários, 
                  criando uma estrutura hierárquica que facilita a manipulação e consulta dos dados.
                </p>
                <div className="space-y-2">
                  <Badge variant="secondary">Dicionários aninhados</Badge>
                  <Badge variant="secondary">Listas de departamentos</Badge>
                  <Badge variant="secondary">Estrutura flexível</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Users className="w-6 h-6 text-green-600" />
                  <CardTitle>Funções Narrativas</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-4">
                  As funções <code className="bg-slate-100 px-2 py-1 rounded">alocacao_projeto()</code> e 
                  <code className="bg-slate-100 px-2 py-1 rounded ml-1">informacoes_funcionario()</code> 
                  criam a narrativa, transformando dados em histórias compreensíveis.
                </p>
                <div className="space-y-2">
                  <Badge variant="secondary">Manipulação de dados</Badge>
                  <Badge variant="secondary">Feedback narrativo</Badge>
                  <Badge variant="secondary">Interação humana</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <ArrowRight className="w-6 h-6 text-orange-600" />
                  <CardTitle>Fluxo Narrativo</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-4">
                  O código segue uma estrutura narrativa clássica: apresentação inicial, 
                  desenvolvimento (mudanças), e conclusão (relatório final).
                </p>
                <div className="space-y-2">
                  <Badge variant="secondary">Introdução</Badge>
                  <Badge variant="secondary">Desenvolvimento</Badge>
                  <Badge variant="secondary">Conclusão</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <BarChart3 className="w-6 h-6 text-blue-600" />
                  <CardTitle>Visualização Final</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-4">
                  A conversão para DataFrame do pandas representa a culminação da narrativa, 
                  apresentando os dados de forma estruturada e profissional.
                </p>
                <div className="space-y-2">
                  <Badge variant="secondary">Pandas DataFrame</Badge>
                  <Badge variant="secondary">Formato tabular</Badge>
                  <Badge variant="secondary">Relatório final</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Data Comparison */}
        <section>
          <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">
            Comparação: Antes e Depois
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-slate-700">Estado Inicial</CardTitle>
                <CardDescription>Alocações originais dos funcionários</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2">Funcionário</th>
                        <th className="text-left py-2">Departamento</th>
                        <th className="text-left py-2">Projeto</th>
                      </tr>
                    </thead>
                    <tbody>
                      {initialData.map((row, index) => (
                        <tr key={index} className="border-b">
                          <td className="py-2 font-medium">{row.funcionario}</td>
                          <td className="py-2">{row.departamento}</td>
                          <td className="py-2">{row.projeto}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-green-200">
              <CardHeader>
                <CardTitle className="text-xl text-green-700">Estado Final</CardTitle>
                <CardDescription>Após as realocações de projeto</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2">Funcionário</th>
                        <th className="text-left py-2">Departamento</th>
                        <th className="text-left py-2">Projeto</th>
                      </tr>
                    </thead>
                    <tbody>
                      {finalData.map((row, index) => (
                        <tr key={index} className="border-b">
                          <td className="py-2 font-medium">{row.funcionario}</td>
                          <td className="py-2">{row.departamento}</td>
                          <td className={`py-2 ${
                            (row.funcionario === 'Ronaldo' || row.funcionario === 'Ronaldinho') 
                              ? 'text-green-600 font-semibold' 
                              : ''
                          }`}>
                            {row.projeto}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Key Concepts */}
        <section className="bg-white rounded-xl p-8 shadow-lg">
          <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">
            Conceitos-Chave Aprendidos
          </h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Narrativa Estruturada</h3>
              <p className="text-slate-600">
                Organizar dados seguindo uma estrutura narrativa clássica com início, meio e fim.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Personagens nos Dados</h3>
              <p className="text-slate-600">
                Transformar pontos de dados em "personagens" com características e histórias próprias.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Visualização Clara</h3>
              <p className="text-slate-600">
                Apresentar resultados de forma clara e profissional usando ferramentas adequadas.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-8 mt-16">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-slate-300">
            Exemplo prático de storytelling de dados usando Python e pandas
          </p>
          <p className="text-slate-400 text-sm mt-2">
            Transformando dados em narrativas compreensíveis e envolventes
          </p>
        </div>
      </footer>
    </div>
  )
}

export default App

